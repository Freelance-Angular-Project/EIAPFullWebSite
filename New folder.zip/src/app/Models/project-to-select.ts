export interface ProjectToSelect {
  id:string;
  name:string;
}
