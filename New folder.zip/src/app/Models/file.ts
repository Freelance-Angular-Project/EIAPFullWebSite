export interface SchoolFile {
  id:string;
  schoolId: string;
  name: string;
  description: string;
  created?: string;
  endDate: string;
  url: string;
  fileName: string;
}
