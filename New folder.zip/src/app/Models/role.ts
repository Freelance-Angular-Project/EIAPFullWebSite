export interface Role {
  roleName:string;
}
