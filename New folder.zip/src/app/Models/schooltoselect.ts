export interface Schooltoselect {
  id:string;
  name:string;
}
