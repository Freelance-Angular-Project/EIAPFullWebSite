export interface News {
  id: string;
  details: string;
  year: Date;
  isEvent: boolean;
  imageUrl: string;
}
