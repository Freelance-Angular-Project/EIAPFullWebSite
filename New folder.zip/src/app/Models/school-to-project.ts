export interface SchoolToProject {
  schoolId: number;
  projectId: number;
}
