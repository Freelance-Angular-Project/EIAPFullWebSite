export interface NewsImageUpdate {
  image: File; // or a string if the image is in base64 format
}
