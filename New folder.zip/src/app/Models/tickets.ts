export interface Tickets {
  projectId:string;
  subject:string;
  description:string;
}
