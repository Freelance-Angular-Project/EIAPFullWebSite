export interface Task {
  id: string;
  name: string;
  endDate: string;
  status: string;
}
