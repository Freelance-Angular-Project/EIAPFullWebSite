import { Component } from '@angular/core';

@Component({
  selector: 'app-tickets-dashboard',
  standalone: true,
  imports: [],
  templateUrl: './tickets-dashboard.component.html',
  styleUrl: './tickets-dashboard.component.scss'
})
export class TicketsDashboardComponent {

}
