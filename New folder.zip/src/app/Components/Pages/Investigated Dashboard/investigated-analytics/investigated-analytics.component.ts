import { Component } from '@angular/core';

@Component({
  selector: 'app-investigated-analytics',
  standalone: true,
  imports: [],
  templateUrl: './investigated-analytics.component.html',
  styleUrl: './investigated-analytics.component.scss'
})
export class InvestigatedAnalyticsComponent {

}
