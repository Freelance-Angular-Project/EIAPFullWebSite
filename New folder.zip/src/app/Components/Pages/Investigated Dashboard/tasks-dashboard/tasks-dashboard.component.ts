import { Component } from '@angular/core';

@Component({
  selector: 'app-tasks-dashboard',
  standalone: true,
  imports: [],
  templateUrl: './tasks-dashboard.component.html',
  styleUrl: './tasks-dashboard.component.scss'
})
export class TasksDashboardComponent {

}
