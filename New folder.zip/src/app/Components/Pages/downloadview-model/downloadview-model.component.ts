import { Component, OnInit } from '@angular/core';
import { SchoolService } from '../../../Services/School/school.service';

@Component({
  selector: 'app-downloadview-model',
  standalone: true,
  imports: [],
  templateUrl: './downloadview-model.component.html',
  styleUrl: './downloadview-model.component.scss'
})
export class DownloadviewModelComponent  {


}
