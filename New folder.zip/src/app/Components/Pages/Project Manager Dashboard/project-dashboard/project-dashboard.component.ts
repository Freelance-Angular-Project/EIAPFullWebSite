import { Component } from '@angular/core';

@Component({
  selector: 'app-project-dashboard',
  standalone: true,
  imports: [],
  templateUrl: './project-dashboard.component.html',
  styleUrl: './project-dashboard.component.scss'
})
export class ProjectDashboardComponent {

}
