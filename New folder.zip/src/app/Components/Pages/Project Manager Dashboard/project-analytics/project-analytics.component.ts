import { Component } from '@angular/core';

@Component({
  selector: 'app-project-analytics',
  standalone: true,
  imports: [],
  templateUrl: './project-analytics.component.html',
  styleUrl: './project-analytics.component.scss'
})
export class ProjectAnalyticsComponent {

}
