import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, catchError, tap, throwError } from 'rxjs';
import { User } from '../../Models/user';
import { LoginResponse } from '../../Models/login-response';
import { jwtDecode } from "jwt-decode";
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private baseUrl =
  `${environment.baseApiURL}/Account`; // Replace with the actual base URL
  // Define the headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      Accept: 'text/plain',
      // Add any other header you need here
    }),
  };

  currentUser: User = {} as User;
  userLoggedBehavior: BehaviorSubject<boolean>;

  constructor(private http: HttpClient) {
    this.userLoggedBehavior = new BehaviorSubject<boolean>(this.isUserLogged);
  }

  // login
  login(email: string, password: string): Observable<LoginResponse> {
    return this.http
      .post<LoginResponse>(
        `${this.baseUrl}/login`,
        { email, password },
        this.httpOptions
      )
      .pipe(
        tap((res) => {
          if (res.isAuthenticated) {
            localStorage.setItem('token', res.token);
            localStorage.setItem('role', res.role[0]);
            // localStorage.setItem('roles', JSON.stringify(res.role[0]));
            this.currentUser = { email: res.email, role: res.role.slice(0, 1) };
            this.userLoggedBehavior.next(true);

            console.log(this.currentUser);
          }
        }),
        catchError((error) => {
          console.error('Login error:', error);
          return throwError(() => new Error('Login failed'));
        })
      );
  }

  getUsersInRole(roleName: string): Observable<LoginResponse[]> {
    return this.http.get<LoginResponse[]>(
      `${this.baseUrl}/usersInRole/${roleName}`
    );
  }

  // Helper method to check if the current user has a specific role
  // hasRole(roleName: string): boolean {
  //   return (
  //     this.currentUser &&
  //     Array.isArray(this.currentUser.role) &&
  //     this.currentUser.role.includes(roleName)
  //   );
  // }

  getuRoles(roleName: string): boolean {
    return localStorage.getItem('role') == roleName ? true : false;
  }
  get isUserLogged(): boolean {
    return localStorage.getItem('token') ? true : false;
  }
  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    this.userLoggedBehavior.next(false);
  }
  getUserLoggedStatus(): Observable<boolean> {
    return this.userLoggedBehavior.asObservable();
  }

  getCurrentUserId(): string | null {
    const token = localStorage.getItem('token');
    if (!token) return null;

    try {
      const decoded: any = jwtDecode(token);
      // Adjust 'userId' to match the property in your token's payload
      return decoded.uid;
    } catch (error) {
      console.error('Decoding token failed', error);
      return null;
    }
  }






  // Replace the parameter and return types with the correct ones based on your API
  registerProjectManager(user: User): Observable<User> {
    return this.http.post<User>(`${this.baseUrl}/registerProjectManager`, user);
  }

  registerSchoolManager(user: User): Observable<User> {
    return this.http.post<User>(`${this.baseUrl}/registerSchoolManager`, user);
  }

  registerInvestigated(user: User): Observable<User> {
    return this.http.post<User>(`${this.baseUrl}/registerInvestigated`, user);
  }

  registerAdmin(user: User): Observable<User> {
    return this.http.post<User>(`${this.baseUrl}/registerAdmin`, user);
  }

  getProfile(): Observable<User> {
    return this.http.get<User>(`${this.baseUrl}/Profile`);
  }
}
