import { SliceWordPipe } from './slice-word.pipe';

describe('SliceWordPipe', () => {
  it('create an instance', () => {
    const pipe = new SliceWordPipe();
    expect(pipe).toBeTruthy();
  });
});
