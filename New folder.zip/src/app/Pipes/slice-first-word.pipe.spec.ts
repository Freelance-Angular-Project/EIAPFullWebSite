import { SliceFirstWordPipe } from './slice-first-word.pipe';

describe('SliceFirstWordPipe', () => {
  it('create an instance', () => {
    const pipe = new SliceFirstWordPipe();
    expect(pipe).toBeTruthy();
  });
});
