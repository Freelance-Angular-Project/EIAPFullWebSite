export const environment = {
  baseApiURL:'https://mohamedellnagar-001-site1.atempurl.com/api'
};
